import { Router, type IRouter } from "express";
import { bot } from "../bot/whatsapp";

const router: IRouter = Router();

router.get("/status", (_req, res) => {
  res.json(bot.getStatus());
});

router.get("/qr", (_req, res) => {
  res.json(bot.getQr());
});

router.get("/logs", (_req, res) => {
  res.json(bot.getLogs());
});

router.get("/config", (_req, res) => {
  res.json(bot.getConfig());
});

router.put("/config", (req, res) => {
  const updates = req.body;
  const config = bot.updateConfig(updates);
  res.json(config);
});

router.post("/disconnect", async (_req, res) => {
  await bot.disconnect();
  res.json({ status: "disconnected" });
});

export default router;
