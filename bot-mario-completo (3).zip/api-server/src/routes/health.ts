import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

// ── Monitoramento UptimeRobot ─────────────────────────────────────────────────
router.get("/ping", (_req, res) => {
  res.status(200).send("OK");
});

router.get("/status", (_req, res) => {
  res.status(200).send("BOT ONLINE");
});

export default router;
