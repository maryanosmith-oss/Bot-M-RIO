import { Router, type IRouter } from "express";
import healthRouter from "./health";
import botRouter from "./bot";
import downloadRouter from "./download";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/bot", botRouter);
router.use("/bot", downloadRouter);

export default router;
