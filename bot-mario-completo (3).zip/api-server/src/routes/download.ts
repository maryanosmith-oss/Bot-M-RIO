import { Router, type IRouter } from "express";
import archiver from "archiver";
import path from "path";

const router: IRouter = Router();

const ROOT = path.resolve("/home/runner/workspace");

router.get("/download", (_req, res) => {
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", 'attachment; filename="bot-mario-completo.zip"');

  const archive = archiver("zip", { zlib: { level: 9 } });

  archive.on("error", (err) => {
    res.status(500).end();
    throw err;
  });

  archive.pipe(res);

  // ── Código-fonte da API (backend do bot) ────────────────────────────────
  archive.directory(path.join(ROOT, "artifacts/api-server/src"), "api-server/src");
  archive.file(path.join(ROOT, "artifacts/api-server/package.json"), { name: "api-server/package.json" });
  archive.file(path.join(ROOT, "artifacts/api-server/tsconfig.json"), { name: "api-server/tsconfig.json" });
  archive.file(path.join(ROOT, "artifacts/api-server/build.mjs"),    { name: "api-server/build.mjs" });

  // ── Código-fonte do Painel (frontend) ───────────────────────────────────
  archive.directory(path.join(ROOT, "artifacts/mario-bot/src"),    "mario-bot/src");
  archive.directory(path.join(ROOT, "artifacts/mario-bot/public"), "mario-bot/public");
  archive.file(path.join(ROOT, "artifacts/mario-bot/package.json"),    { name: "mario-bot/package.json" });
  archive.file(path.join(ROOT, "artifacts/mario-bot/tsconfig.json"),   { name: "mario-bot/tsconfig.json" });
  archive.file(path.join(ROOT, "artifacts/mario-bot/vite.config.ts"),  { name: "mario-bot/vite.config.ts" });
  archive.file(path.join(ROOT, "artifacts/mario-bot/tailwind.config.ts"), { name: "mario-bot/tailwind.config.ts" }).on("error", () => {});
  archive.file(path.join(ROOT, "artifacts/mario-bot/index.html"),      { name: "mario-bot/index.html" });

  // ── Libs compartilhadas ─────────────────────────────────────────────────
  const libs = ["api-zod", "db"];
  for (const lib of libs) {
    const libPath = path.join(ROOT, "lib", lib);
    archive.directory(libPath, `lib/${lib}`);
  }

  // ── Arquivos raiz do monorepo ───────────────────────────────────────────
  archive.file(path.join(ROOT, "package.json"),           { name: "package.json" });
  archive.file(path.join(ROOT, "pnpm-workspace.yaml"),    { name: "pnpm-workspace.yaml" });
  archive.file(path.join(ROOT, "tsconfig.base.json"),     { name: "tsconfig.base.json" });
  archive.file(path.join(ROOT, "tsconfig.json"),          { name: "tsconfig.json" });
  archive.file(path.join(ROOT, "replit.md"),              { name: "README.md" }).on("error", () => {});

  // ── Arquivo de deploy Render ────────────────────────────────────────────
  archive.file(path.join(ROOT, "render.yaml"), { name: "render.yaml" }).on("error", () => {});

  // ── README de instalação ────────────────────────────────────────────────
  const readme = `# Bot MÁRIO — Instalação

## Pré-requisitos
- Node.js 20+
- pnpm 10+  (npm install -g pnpm)
- Chromium instalado no sistema

## Instalar dependências
\`\`\`bash
pnpm install
\`\`\`

## Variáveis de ambiente
Crie um arquivo \`.env\` na pasta \`artifacts/api-server/\` com:
\`\`\`
PORT=3000
SESSION_PATH=./session          # pasta onde a sessão do WhatsApp é salva
OPENAI_API_KEY=sua_chave        # opcional – modo auto-resposta
DATABASE_URL=sua_url_postgres   # opcional – XP e grupos
\`\`\`

## Rodar localmente
\`\`\`bash
# Terminal 1 – API + Bot WhatsApp
cd artifacts/api-server
pnpm dev

# Terminal 2 – Painel Web
cd artifacts/mario-bot
pnpm dev
\`\`\`

Acesse o painel em http://localhost:5173 e escaneie o QR Code com o WhatsApp.

---

## Deploy no Render (24h sem cair)

O arquivo render.yaml já está configurado. Siga os passos:

1. Crie uma conta em https://render.com
2. Clique em "New" → "Blueprint" → conecte seu repositório Git
3. O Render detecta o render.yaml automaticamente e configura tudo
4. Na seção "Environment Variables", adicione:
   - OPENAI_API_KEY (se usar modo auto-resposta)
5. O disco persistente (whatsapp-session) já está configurado no render.yaml
   → A sessão do WhatsApp NÃO será perdida ao reiniciar

### Health check
O servidor responde em GET / com "Bot online"
O Render usa essa rota para saber que o serviço está ativo.

### Reconexão automática
O Guardian verifica o estado do bot a cada 45s e reconecta se necessário.
Erros não derrubam o processo (uncaughtException/unhandledRejection tratados).
`;

  archive.append(readme, { name: "COMO-INSTALAR.txt" });

  archive.finalize();
});

export default router;
