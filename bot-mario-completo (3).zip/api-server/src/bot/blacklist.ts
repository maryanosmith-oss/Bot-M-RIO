import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join } from "path";

const CONFIG_DIR = "/tmp/mario_config";
const BLACKLIST_PATH = join(CONFIG_DIR, "blacklist.json");

interface BlacklistDB {
  numeros: string[];
}

function ensureDir() {
  if (!existsSync(CONFIG_DIR)) mkdirSync(CONFIG_DIR, { recursive: true });
}

function load(): BlacklistDB {
  ensureDir();
  if (existsSync(BLACKLIST_PATH)) {
    try {
      return JSON.parse(readFileSync(BLACKLIST_PATH, "utf-8"));
    } catch {}
  }
  return { numeros: [] };
}

function save(db: BlacklistDB) {
  ensureDir();
  writeFileSync(BLACKLIST_PATH, JSON.stringify(db, null, 2));
}

function normalizar(numero: string): string {
  return numero.replace(/[^0-9]/g, "").replace(/^0+/, "");
}

export function blacklistAdd(numero: string): string {
  const n = normalizar(numero);
  if (!n || n.length < 8) return "❌ Número inválido! Use DDD + número (ex: 11999999999)";
  const db = load();
  if (db.numeros.includes(n)) return `⚠️ *${n}* já está na lista negra!`;
  db.numeros.push(n);
  save(db);
  return `✅ *${n}* adicionado à lista negra! 🚫`;
}

export function blacklistDel(numero: string): string {
  const n = normalizar(numero);
  const db = load();
  const antes = db.numeros.length;
  db.numeros = db.numeros.filter((x) => x !== n);
  if (db.numeros.length === antes) return `⚠️ *${n}* não está na lista negra!`;
  save(db);
  return `✅ *${n}* removido da lista negra!`;
}

export function blacklistList(): string {
  const db = load();
  if (!db.numeros.length) return "📭 Lista negra vazia.";
  const linhas = db.numeros.map((n, i) => `${i + 1}. \`${n}\``);
  return `🚫 *Lista Negra (${db.numeros.length}):*\n\n${linhas.join("\n")}`;
}

export function isBlacklisted(senderId: string): boolean {
  const db = load();
  const user = senderId.split("@")[0];
  return db.numeros.some((n) => user.includes(n) || n.includes(user));
}

export async function checkAndRemoveBlacklisted(
  group: any,
  participantIds: string[],
): Promise<string[]> {
  const removed: string[] = [];
  for (const id of participantIds) {
    if (isBlacklisted(id)) {
      try {
        await group.removeParticipants([id]);
        removed.push(id.split("@")[0]);
      } catch {}
    }
  }
  return removed;
}
