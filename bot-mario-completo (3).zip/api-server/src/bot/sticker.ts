import { execFile } from "child_process";
import { promisify } from "util";
import { writeFile, readFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import sharp from "sharp";

const execFileAsync = promisify(execFile);

function findFfmpeg(): string {
  return process.env.FFMPEG_PATH || "ffmpeg";
}

export async function createStickerFromImage(
  base64Data: string,
  mimetype: string,
): Promise<Buffer> {
  const inputBuffer = Buffer.from(base64Data, "base64");
  return sharp(inputBuffer)
    .resize(512, 512, {
      fit: "contain",
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    })
    .webp({ quality: 80 })
    .toBuffer();
}

export async function createStickerFromVideo(
  base64Data: string,
  mimetype: string,
): Promise<Buffer> {
  const tmpDir = tmpdir();
  const ext = mimetype.includes("gif") ? "gif" : "mp4";
  const inputPath = join(tmpDir, `sticker_in_${Date.now()}.${ext}`);
  const outputPath = join(tmpDir, `sticker_out_${Date.now()}.webp`);
  try {
    await writeFile(inputPath, Buffer.from(base64Data, "base64"));
    await execFileAsync(findFfmpeg(), [
      "-i", inputPath,
      "-vf", "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,fps=15",
      "-vcodec", "libwebp",
      "-lossless", "0",
      "-compression_level", "6",
      "-q:v", "50",
      "-loop", "0",
      "-preset", "default",
      "-an", "-vsync", "0",
      "-t", "6",
      "-y", outputPath,
    ]);
    return readFile(outputPath);
  } finally {
    unlink(inputPath).catch(() => {});
    unlink(outputPath).catch(() => {});
  }
}

export async function createSticker(
  base64Data: string,
  mimetype: string,
): Promise<Buffer> {
  const isVideo = mimetype.includes("video") || mimetype.includes("gif") || mimetype.includes("webp");
  return isVideo
    ? createStickerFromVideo(base64Data, mimetype)
    : createStickerFromImage(base64Data, mimetype);
}

export async function createTextSticker(
  text: string,
  bg = "#1a1a2e",
  fg = "#ffffff",
  animated = false,
): Promise<Buffer> {
  const lines = text.match(/.{1,20}/g) || [text];
  const lineHeight = 80;
  const padding = 40;
  const height = Math.min(512, lines.length * lineHeight + padding * 2);

  const tspans = lines
    .map((line, i) => `<tspan x="256" dy="${i === 0 ? 0 : lineHeight}">${line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</tspan>`)
    .join("");

  const svg = `<svg width="512" height="${height}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${bg}"/>
        <stop offset="100%" stop-color="${bg}dd"/>
      </linearGradient>
    </defs>
    <rect width="512" height="${height}" fill="url(#bg)" rx="20"/>
    <text x="256" y="${padding + 20}" font-family="Arial, sans-serif" font-size="60" font-weight="bold"
      fill="${fg}" text-anchor="middle" dominant-baseline="middle" 
      style="filter: drop-shadow(2px 2px 4px rgba(0,0,0,0.5))">
      ${tspans}
    </text>
  </svg>`;

  return sharp(Buffer.from(svg))
    .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 90 })
    .toBuffer();
}

export async function stickerToImage(base64Data: string): Promise<Buffer> {
  return sharp(Buffer.from(base64Data, "base64"))
    .png()
    .toBuffer();
}
