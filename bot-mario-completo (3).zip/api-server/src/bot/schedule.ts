import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join } from "path";
import cron from "node-cron";

const CONFIG_DIR = "/tmp/mario_config";
const AGENDAMENTOS_PATH = join(CONFIG_DIR, "agendamentos.json");

export interface Agendamento {
  id: string;
  tipo: "fechargp" | "abrirgp" | "msg";
  groupId: string;
  hora: string;
  minuto: string;
  texto?: string;
  cronJob?: string;
}

interface AgendamentosDB {
  itens: Agendamento[];
}

let botClientRef: any = null;
const cronJobs: Map<string, cron.ScheduledTask> = new Map();

function ensureDir() {
  if (!existsSync(CONFIG_DIR)) mkdirSync(CONFIG_DIR, { recursive: true });
}

function load(): AgendamentosDB {
  ensureDir();
  if (existsSync(AGENDAMENTOS_PATH)) {
    try {
      return JSON.parse(readFileSync(AGENDAMENTOS_PATH, "utf-8"));
    } catch {}
  }
  return { itens: [] };
}

function save(db: AgendamentosDB) {
  ensureDir();
  writeFileSync(AGENDAMENTOS_PATH, JSON.stringify(db, null, 2));
}

function parseHorario(horario: string): { hora: string; minuto: string } | null {
  const match = horario.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const h = parseInt(match[1]);
  const m = parseInt(match[2]);
  if (h < 0 || h > 23 || m < 0 || m > 59) return null;
  return { hora: String(h), minuto: String(m).padStart(2, "0") };
}

function agendarJob(item: Agendamento) {
  const expression = `${item.minuto} ${item.hora} * * *`;
  if (!cron.validate(expression)) return;

  const task = cron.schedule(
    expression,
    async () => {
      if (!botClientRef) return;
      try {
        if (item.tipo === "fechargp") {
          const chat = await botClientRef.getChatById(item.groupId);
          if (chat?.isGroup) {
            await (chat as any).setMessagesAdminsOnly(true);
            await (chat as any).sendMessage("🔒 *Grupo fechado automaticamente!* (agendamento)");
          }
        } else if (item.tipo === "abrirgp") {
          const chat = await botClientRef.getChatById(item.groupId);
          if (chat?.isGroup) {
            await (chat as any).setMessagesAdminsOnly(false);
            await (chat as any).sendMessage("🔓 *Grupo aberto automaticamente!* (agendamento)");
          }
        } else if (item.tipo === "msg" && item.texto) {
          const chat = await botClientRef.getChatById(item.groupId);
          if (chat) await chat.sendMessage(item.texto);
        }
      } catch {}
    },
    { timezone: "America/Sao_Paulo" },
  );

  cronJobs.set(item.id, task);
}

export function initScheduler(client: any) {
  botClientRef = client;
  const db = load();
  for (const item of db.itens) {
    agendarJob(item);
  }
}

export function agendarFechargp(groupId: string, horario: string): string {
  const parsed = parseHorario(horario);
  if (!parsed) return "❌ Formato inválido. Use HH:MM (ex: 22:00)";
  const db = load();
  const id = `fechargp_${groupId}_${Date.now()}`;
  const item: Agendamento = { id, tipo: "fechargp", groupId, hora: parsed.hora, minuto: parsed.minuto };
  db.itens.push(item);
  save(db);
  agendarJob(item);
  return `✅ *Grupo será FECHADO* todo dia às *${horario}* ⏰`;
}

export function agendarAbrirgp(groupId: string, horario: string): string {
  const parsed = parseHorario(horario);
  if (!parsed) return "❌ Formato inválido. Use HH:MM (ex: 08:00)";
  const db = load();
  const id = `abrirgp_${groupId}_${Date.now()}`;
  const item: Agendamento = { id, tipo: "abrirgp", groupId, hora: parsed.hora, minuto: parsed.minuto };
  db.itens.push(item);
  save(db);
  agendarJob(item);
  return `✅ *Grupo será ABERTO* todo dia às *${horario}* ⏰`;
}

export function agendarMensagem(groupId: string, horario: string, texto: string): string {
  const parsed = parseHorario(horario);
  if (!parsed) return "❌ Formato inválido. Use HH:MM (ex: 09:00)";
  if (!texto?.trim()) return "❌ Informe o texto da mensagem!";
  const db = load();
  const id = `msg_${groupId}_${Date.now()}`;
  const item: Agendamento = { id, tipo: "msg", groupId, hora: parsed.hora, minuto: parsed.minuto, texto };
  db.itens.push(item);
  save(db);
  agendarJob(item);
  return `✅ *Mensagem agendada* para *${horario}* todo dia!\n\n📝 "${texto}"`;
}

export function listarAgendamentos(groupId: string): string {
  const db = load();
  const itens = db.itens.filter((i) => i.groupId === groupId);
  if (!itens.length) return "📭 Nenhum agendamento neste grupo.";
  const linhas = itens.map((i, idx) => {
    const emoji = i.tipo === "fechargp" ? "🔒" : i.tipo === "abrirgp" ? "🔓" : "💬";
    const hora = `${i.hora}:${i.minuto}`;
    const extra = i.texto ? ` — "${i.texto}"` : "";
    return `${idx + 1}. ${emoji} *${i.tipo}* às *${hora}*${extra}`;
  });
  return `⏰ *Agendamentos do grupo:*\n\n${linhas.join("\n")}`;
}

export function cancelarAgendamento(groupId: string, indice: number): string {
  const db = load();
  const itens = db.itens.filter((i) => i.groupId === groupId);
  const idx = indice - 1;
  if (idx < 0 || idx >= itens.length) return "❌ Índice inválido!";
  const item = itens[idx];
  const job = cronJobs.get(item.id);
  if (job) { job.stop(); cronJobs.delete(item.id); }
  db.itens = db.itens.filter((i) => i.id !== item.id);
  save(db);
  return `✅ Agendamento *#${indice}* cancelado!`;
}
