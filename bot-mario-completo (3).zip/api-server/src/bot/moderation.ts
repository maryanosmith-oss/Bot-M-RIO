/**
 * MODERAÇÃO AUTOMÁTICA — Bot MÁRIO
 * Módulo 100% independente. Não modifica protection.ts nem nenhum código existente.
 *
 * Inclui:
 *  - Sistema de advertências (warn → ban automático)
 *  - Todos os filtros de conteúdo novos (imagem, áudio, gif, sticker, vídeo, etc.)
 *  - Detecção de pornografia/palavrões por palavras-chave contextuais
 *  - AutoFig (imagem → figurinha automática)
 *  - Anti-link de grupo WhatsApp
 *  - Anti-vírus (documentos executáveis)
 */

import { Message, GroupChat, MessageMedia } from "whatsapp-web.js";
import { getGroup, saveGroup } from "./db";
import { logger } from "../lib/logger";
import { createSticker } from "./sticker";

// ─────────────────────────────────────────────────────────────────────────────
// LISTAS DE DETECÇÃO
// ─────────────────────────────────────────────────────────────────────────────

const PALAVROES_BR = [
  "caralho","puta","merda","porra","viado","cuzao","buceta","fdp","viadao",
  "filho da puta","arrombado","corno","piroca","punheta","cacete","bronha",
  "rola","xota","xoxota","gozar","trepar","cagar","mijar","bosta","escroto",
  "pinto","otario","babaca","safado","safada","desgraçado","desgraçada",
  "vai se foder","vsf","foda","foder","fuder","puto","vagabunda","vaca",
  "prostituta","cuzada","cu","idiota","imbecil","retardado","cretino",
  // variações com símbolos/censura
  "p0rra","m3rda","c4ralho","put4","c@ralho","p*rra","v1ado",
];

const KEYWORDS_PORNO = [
  "porn","porno","pornô","pornografia","sexo","sexting","nude","nudes",
  "pelado","pelada","putaria","sacanagem","orgasmo","masturbação","masturbando",
  "xvideos","xnxx","pornhub","onlyfans","stripper","boquete","chupar",
  "pack","video intimo","foto intima","conteudo adulto","+18","18+",
  "safadeza","tarado","tarada","pervertido","fetiche","tesão","tesao",
  "goza","gozando","sexo oral","sexo anal","sexo virtual","cam show",
];

const VIRUS_EXTENSIONS = [
  ".exe",".bat",".cmd",".com",".scr",".pif",".msi",".vbs",".js",".jar",
  ".ps1",".sh",".dmg",".apk",".ipa",".dll",".reg",".sys",".inf",
];

const WA_GROUP_LINK_REGEX = /chat\.whatsapp\.com\/[A-Za-z0-9]+/gi;

// ─────────────────────────────────────────────────────────────────────────────
// UTILITÁRIOS
// ─────────────────────────────────────────────────────────────────────────────

/** Normaliza texto para detecção: minúsculas, sem acentos, remove espaços duplos */
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Detecção contextual — verifica variações e fragmentos */
function detectKeywords(text: string, keywords: string[]): string | null {
  const norm = normalizeText(text);
  for (const kw of keywords) {
    const kwNorm = normalizeText(kw);
    // busca como palavra inteira OU fragmento (para evitar falso positivo em palavras compostas)
    const regex = new RegExp(`(?:^|\\s)${kwNorm.replace(/\s+/g, "\\s+")}(?:\\s|$)`, "i");
    if (regex.test(norm) || norm.includes(kwNorm)) return kw;
  }
  return null;
}

/** Obtém chave do usuário normalizada para o banco de advertências */
function userKey(senderId: string): string {
  return senderId.split("@")[0];
}

// ─────────────────────────────────────────────────────────────────────────────
// SISTEMA DE ADVERTÊNCIAS
// ─────────────────────────────────────────────────────────────────────────────

export function getWarnInfo(groupId: string, senderId: string): { count: number; limit: number } {
  const group = getGroup(groupId);
  const key = userKey(senderId);
  const count = (group.warnings ?? {})[key] ?? 0;
  return { count, limit: group.warnLimit ?? 3 };
}

export function addWarning(
  groupId: string,
  senderId: string,
): { count: number; limit: number; exceeded: boolean } {
  const group = getGroup(groupId);
  if (!group.warnings) group.warnings = {};
  const key = userKey(senderId);
  group.warnings[key] = (group.warnings[key] ?? 0) + 1;
  const limit = group.warnLimit ?? 3;
  const count = group.warnings[key];
  saveGroup(group);
  return { count, limit, exceeded: count >= limit };
}

export function resetUserWarnings(groupId: string, senderId: string): void {
  const group = getGroup(groupId);
  if (!group.warnings) return;
  const key = userKey(senderId);
  delete group.warnings[key];
  saveGroup(group);
}

export function resetAllWarnings(groupId: string): void {
  const group = getGroup(groupId);
  group.warnings = {};
  saveGroup(group);
}

export function setWarnLimit(groupId: string, limit: number): void {
  const group = getGroup(groupId);
  group.warnLimit = limit;
  saveGroup(group);
}

// ─────────────────────────────────────────────────────────────────────────────
// VERIFICAÇÃO DE MODERAÇÃO
// ─────────────────────────────────────────────────────────────────────────────

export interface ModerationViolation {
  violated: true;
  rule: string;
  label: string;
}
export interface ModerationPass { violated: false }
export type ModerationResult = ModerationViolation | ModerationPass;

export async function checkModeration(
  msg: Message,
  chat: GroupChat,
  senderId: string,
): Promise<ModerationResult> {
  const group = getGroup(chat.id._serialized);
  const body = msg.body?.trim() ?? "";
  const type = msg.type as string;
  const isGif = (msg as any).isGif === true;

  // Admins são imunes à moderação
  const senderUser = senderId.split("@")[0];
  const participant = chat.participants.find(
    (p) => p.id._serialized === senderId || p.id.user === senderUser,
  );
  if (participant?.isAdmin || participant?.isSuperAdmin) return { violated: false };

  // helper
  const hit = (rule: string, label: string): ModerationViolation =>
    ({ violated: true, rule, label });

  // ── 1. Anti-vírus (documentos executáveis) ─────────────────────────────
  if (group.antivirus && type === "document") {
    const fname = ((msg as any)._data?.filename ?? body ?? "").toLowerCase();
    if (VIRUS_EXTENSIONS.some((ext) => fname.endsWith(ext))) {
      return hit("antivirus", "Arquivo suspeito/executável detectado");
    }
  }

  // ── 2. Anti-imagem ─────────────────────────────────────────────────────
  if (group.antiimagem && type === "image" && !isGif) {
    return hit("antiimagem", "Envio de imagens bloqueado");
  }

  // ── 3. Anti-áudio ──────────────────────────────────────────────────────
  if (group.antiaudio && (type === "audio" || type === "ptt")) {
    return hit("antiaudio", "Envio de áudios bloqueado");
  }

  // ── 4. Anti-localização ────────────────────────────────────────────────
  if (group.antilocalizacao && type === "location") {
    return hit("antilocalizacao", "Envio de localização bloqueado");
  }

  // ── 5. Anti-link de grupo WhatsApp ─────────────────────────────────────
  if (group.antilinkgp && WA_GROUP_LINK_REGEX.test(body)) {
    return hit("antilinkgp", "Link de grupo WhatsApp detectado");
  }

  // ── 6. Anti-GIF ────────────────────────────────────────────────────────
  if (group.antigif && (isGif || (type === "video" && isGif))) {
    return hit("antigif", "Envio de GIFs bloqueado");
  }

  // ── 7. Anti-figurinha ──────────────────────────────────────────────────
  if (group.antifigurinha && type === "sticker") {
    return hit("antifigurinha", "Envio de figurinhas bloqueado");
  }

  // ── 8. Anti-palavrão em texto (avançado com variações) ─────────────────
  if (group.antipalavraomod && body) {
    const found = detectKeywords(body, PALAVROES_BR);
    if (found) return hit("antipalavraomod", `Palavrão detectado`);
  }

  // ── 9. Anti-palavrão em áudio (bloqueio de todos os áudios) ─────────────
  if (group.antipalavraoaudio && (type === "audio" || type === "ptt")) {
    return hit("antipalavraoaudio", "Áudio potencialmente com palavrões bloqueado");
  }

  // ── 10. Anti-palavrão em vídeo ──────────────────────────────────────────
  if (group.antipalavraovideo && type === "video") {
    return hit("antipalavraovideo", "Vídeo potencialmente com palavrões bloqueado");
  }

  // ── 11. Anti-pornografia em texto ───────────────────────────────────────
  if (group.antipornografiatexto && body) {
    const found = detectKeywords(body, KEYWORDS_PORNO);
    if (found) return hit("antipornografiatexto", "Conteúdo adulto em texto detectado");
  }

  // ── 12. Anti-pornografia em imagem ──────────────────────────────────────
  if (group.antipornografiaimagem && type === "image" && !isGif) {
    return hit("antipornografiaimagem", "Imagem potencialmente adulta bloqueada");
  }

  // ── 13. Anti-pornografia em vídeo ───────────────────────────────────────
  if (group.antipornografiavideo && type === "video" && !isGif) {
    return hit("antipornografiavideo", "Vídeo potencialmente adulto bloqueado");
  }

  // ── 14. Anti-pornografia em áudio ───────────────────────────────────────
  if (group.antipornografiaaudio && (type === "audio" || type === "ptt")) {
    return hit("antipornografiaaudio", "Áudio potencialmente adulto bloqueado");
  }

  // ── 15. Anti-pornografia em GIF ─────────────────────────────────────────
  if (group.antipornografiagif && isGif) {
    return hit("antipornografiagif", "GIF potencialmente adulto bloqueado");
  }

  // ── 16. Anti-figurinha pornográfica ─────────────────────────────────────
  if (group.antifigurinhapornografica && type === "sticker") {
    return hit("antifigurinhapornografica", "Figurinha potencialmente adulta bloqueada");
  }

  return { violated: false };
}

// ─────────────────────────────────────────────────────────────────────────────
// APLICAR CONSEQUÊNCIA (ADVERTÊNCIA → REMOÇÃO)
// ─────────────────────────────────────────────────────────────────────────────

export async function applyModeration(
  msg: Message,
  chat: GroupChat,
  result: ModerationViolation,
  isBotAdmin: boolean,
  senderId: string,
  contactName: string,
): Promise<void> {
  try {
    // 1. Deletar mensagem
    if (isBotAdmin) {
      try { await msg.delete(true); } catch {}
    }

    const groupId = chat.id._serialized;
    const userNum = senderId.split("@")[0];
    const userTag = `@${userNum}`;

    // 2. Obter contato para mention
    let contact: any = null;
    try { contact = await msg.getContact(); } catch {}
    const mentions = contact ? [contact] : [];

    // 3. Registrar advertência
    const { count, limit, exceeded } = addWarning(groupId, senderId);

    // 4. Enviar aviso ou remover
    if (exceeded) {
      // Remover usuário
      const removeMsgText =
        `🚫 *Conteúdo proibido detectado!*\n` +
        `📌 Regra: ${result.label}\n\n` +
        `${userTag} foi *removido* do grupo após atingir ${limit} avisos!`;

      await chat.sendMessage(removeMsgText, { mentions });

      if (isBotAdmin) {
        try { await chat.removeParticipants([senderId]); } catch {}
      }
      // Reseta advertências após remoção
      resetUserWarnings(groupId, senderId);
    } else {
      const warnText =
        `🚫 *Conteúdo proibido detectado!*\n` +
        `📌 Regra: ${result.label}\n\n` +
        `⚠️ ${userTag} — Aviso *${count}/${limit}*\n` +
        `${count >= limit - 1 ? "⛔ *Próximo aviso resultará em remoção!*" : "Respeite as regras do grupo."}`;

      await chat.sendMessage(warnText, { mentions });
    }
  } catch (err) {
    logger.error({ err }, "[MODERATION] Erro ao aplicar ação de moderação");
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTO-FIG (imagem → figurinha automática)
// ─────────────────────────────────────────────────────────────────────────────

export async function handleAutoFig(msg: Message, chat: GroupChat): Promise<void> {
  try {
    const media = await msg.downloadMedia();
    if (!media?.data) return;
    const buffer = await createSticker(media.data, media.mimetype);
    const stickerMedia = new MessageMedia("image/webp", buffer.toString("base64"), "sticker.webp");
    await chat.sendMessage(stickerMedia, {
      sendMediaAsSticker: true,
      stickerAuthor: "MÁRIO Bot",
      stickerName: "AutoFig",
    });
  } catch (err) {
    logger.warn({ err }, "[MODERATION] AutoFig: erro ao converter figurinha");
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TOGGLE HELPER para os comandos de admin
// ─────────────────────────────────────────────────────────────────────────────

export type ModerationFeature =
  | "antivirus" | "antiimagem" | "antiaudio" | "antilocalizacao"
  | "antilinkgp" | "antigif" | "antifigurinha" | "antipalavraomod"
  | "antipalavraoaudio" | "antipalavraovideo"
  | "antipornografiatexto" | "antipornografiaimagem"
  | "antipornografiavideo" | "antipornografiaaudio"
  | "antipornografiagif" | "antifigurinhapornografica"
  | "autofig";

/** Todas as features gerenciadas por este módulo */
export const ALL_MOD_FEATURES: ModerationFeature[] = [
  "antivirus", "antiimagem", "antiaudio", "antilocalizacao",
  "antilinkgp", "antigif", "antifigurinha", "antipalavraomod",
  "antipalavraoaudio", "antipalavraovideo",
  "antipornografiatexto", "antipornografiaimagem",
  "antipornografiavideo", "antipornografiaaudio",
  "antipornografiagif", "antifigurinhapornografica",
  "autofig",
];

/** Define explicitamente o valor de uma feature */
export function toggleModeration(groupId: string, feature: ModerationFeature, value: boolean): void {
  const group = getGroup(groupId);
  (group as any)[feature] = value;
  saveGroup(group);
}

/** Alterna a feature (toggle: se estiver ligada, desliga; se desligada, liga) */
export function flipModeration(groupId: string, feature: ModerationFeature): boolean {
  const group = getGroup(groupId);
  const current = !!(group as any)[feature];
  (group as any)[feature] = !current;
  saveGroup(group);
  return !current; // retorna o novo estado
}

/** Liga ou desliga TODAS as features de moderação avançada de uma vez */
export function setAllModeration(groupId: string, value: boolean): void {
  const group = getGroup(groupId);
  for (const feature of ALL_MOD_FEATURES) {
    (group as any)[feature] = value;
  }
  saveGroup(group);
}
