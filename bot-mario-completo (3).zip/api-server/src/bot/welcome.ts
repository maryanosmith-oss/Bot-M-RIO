import { GroupChat, GroupParticipant, MessageMedia } from "whatsapp-web.js";
import { getGroup, saveGroup } from "./db";
import { logger } from "../lib/logger";

export async function handleMemberJoin(
  chat: GroupChat,
  participants: GroupParticipant[],
  groupId: string,
): Promise<void> {
  const group = getGroup(groupId);
  if (!group.welcome) return;

  // Garante campos novos em grupos antigos que ainda não os têm
  if (!("welcomeMediaBase64" in group)) {
    (group as any).welcomeMediaBase64 = null;
    (group as any).welcomeMediaMime = null;
  }

  for (const participant of participants) {
    try {
      const userId = participant.id._serialized;
      const userTag = `@${participant.id.user}`;

      const welcomeText = group.welcomeMsg
        .replace(/@user/gi, userTag)
        .replace(/{nome}/gi, userTag)
        .replace(/{grupo}/gi, chat.name);

      // Busca contato para mentions
      const mentions: any[] = [];
      try {
        const contact = await chat.client.getContactById(userId);
        mentions.push(contact);
      } catch {}

      // ── 1. Prioridade: imagem enviada da galeria (base64 no banco) ──
      if (group.welcomeMediaBase64 && group.welcomeMediaMime) {
        try {
          const media = new MessageMedia(
            group.welcomeMediaMime,
            group.welcomeMediaBase64,
            "welcome.jpg",
          );
          await chat.sendMessage(media, { caption: welcomeText, mentions });
          continue;
        } catch (err) {
          logger.warn({ err }, "Falha ao enviar imagem base64 de boas-vindas, caindo para texto");
        }
      }

      // ── 2. Fallback: URL externa (legado) ──
      if (group.welcomeMedia) {
        try {
          const media = await MessageMedia.fromUrl(group.welcomeMedia, { unsafeMime: true });
          await chat.sendMessage(media, { caption: welcomeText, mentions });
          continue;
        } catch {
          logger.warn("Falha ao baixar imagem de URL, caindo para texto");
        }
      }

      // ── 3. Apenas texto ──
      await chat.sendMessage(welcomeText, { mentions });
    } catch (err) {
      logger.error({ err }, "Erro ao enviar mensagem de boas-vindas");
    }
  }
}

export function setWelcome(groupId: string, enabled: boolean): void {
  const group = getGroup(groupId);
  group.welcome = enabled;
  saveGroup(group);
}

export function setWelcomeMessage(
  groupId: string,
  msg: string,
  mediaUrl?: string,
): void {
  const group = getGroup(groupId);
  group.welcomeMsg = msg;
  if (mediaUrl !== undefined) group.welcomeMedia = mediaUrl || null;
  saveGroup(group);
}

export function setWelcomeMediaBase64(
  groupId: string,
  base64: string,
  mime: string,
): void {
  const group = getGroup(groupId);
  group.welcomeMediaBase64 = base64;
  group.welcomeMediaMime = mime;
  group.welcomeMedia = null; // limpa URL antiga quando há imagem real
  saveGroup(group);
}

export function clearWelcomeMedia(groupId: string): void {
  const group = getGroup(groupId);
  group.welcomeMediaBase64 = null;
  group.welcomeMediaMime = null;
  group.welcomeMedia = null;
  saveGroup(group);
}
