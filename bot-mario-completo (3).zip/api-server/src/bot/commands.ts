import { Message, MessageMedia, GroupChat, Chat } from "whatsapp-web.js";
import { generateAIResponse, generateImage, generateTTS } from "./ai";
import { createSticker, createTextSticker, stickerToImage } from "./sticker";
import { logger } from "../lib/logger";
import type { BotConfig } from "./whatsapp";
import { addXp } from "./db";

import {
  cmdBan, cmdKick, cmdAdd, cmdPromote, cmdDemote,
  cmdMute, cmdUnmute, cmdGrupo, cmdLinkgp, cmdResetlink,
  cmdMarcar, cmdHidetag,
  cmdAntispam, cmdAntitrava, cmdAntilink, cmdAntifake, cmdAntipalavrao,
  cmdWelcome,
  // Moderação avançada
  cmdAntivirus, cmdAntiimagem, cmdAntiaudio, cmdAntilocalizacao, cmdAntilinkgp,
  cmdAntigif, cmdAntifigurinha, cmdAntipalavraomod, cmdAntipalavraoaudio, cmdAntipalavraovideo,
  cmdAntipornografiatexto, cmdAntipornografiaimagem, cmdAntipornografiavideo,
  cmdAntipornografiaaudio, cmdAntipornografiagif, cmdAntifigurinhapornografica,
  cmdAutofig,
  // Sistema de advertências
  cmdSetadv, cmdResetadv, cmdAdv,
  // Agendamento
  cmdFechargp, cmdAbrirgp, cmdAgendamentos, cmdCancelarAg,
  // Status de moderação
  cmdModstatus,
  // Globais
  cmdAtivartodos, cmdDesativartodos,
} from "./cmd/admin";

import {
  cmdRank, cmdLevel, cmdXp, cmdDado, cmdCassino, cmdRoleta,
  cmdPpt, cmdQuiz, cmdShip, cmdCasal, checkQuizAnswer,
} from "./cmd/fun";

import {
  cmdHora, cmdCalc, cmdCep, cmdClima, cmdTraduz, cmdWiki, cmdGoogle,
  cmdPing, cmdInfo,
} from "./cmd/utils";

import {
  cmdSaldo, cmdDaily, cmdWork, cmdTransfer, cmdBank,
} from "./cmd/economy";

import {
  cmdYtmp3, cmdYtmp4, cmdPlay, cmdTiktok, cmdInstagram, cmdFacebook,
} from "./cmd/downloads";

import {
  agendarFechargp, agendarAbrirgp, agendarMensagem,
  listarAgendamentos, cancelarAgendamento,
} from "./schedule";

import {
  blacklistAdd, blacklistDel, blacklistList,
} from "./blacklist";

import { revelarViewOnce } from "./viewonce";

export interface CommandContext {
  msg: Message;
  chat: Chat;
  args: string[];
  argString: string;
  config: BotConfig;
  isGroup: boolean;
  contactName: string;
  senderId: string;
  addLog: (
    level: "info" | "warn" | "error" | "success",
    message: string,
    from?: string | null,
    isGroup?: boolean | null,
  ) => void;
}

export type CommandHandler = (ctx: CommandContext) => Promise<void>;

async function cmdMenu(ctx: CommandContext) {
  const p = ctx.config.prefix;
  const menu = `🤖 *BOT ${ctx.config.botName.toUpperCase()} — MENU COMPLETO*

╔══════════════════════════════════╗
║  📌 *MENU & AJUDA*               ║
║  ${p}menu  ${p}help <cmd>              ║
╠══════════════════════════════════╣
║  👑 *ADMINISTRAÇÃO*              ║
║  ${p}ban  ${p}kick  ${p}add  ${p}promote        ║
║  ${p}demote  ${p}mute  ${p}unmute         ║
║  ${p}grupo  ${p}linkgp  ${p}resetlink     ║
║  ${p}marcar  ${p}hidetag              ║
╠══════════════════════════════════╣
║  🛡️ *PROTEÇÃO*                   ║
║  ${p}antispam on/off               ║
║  ${p}antitrava on/off              ║
║  ${p}antilink on/off               ║
║  ${p}antifake on/off               ║
║  ${p}antipalavrao on/off           ║
║  ${p}welcome on/off [msg] [url]    ║
╠══════════════════════════════════╣
║  🎨 *FIGURINHAS*                 ║
║  ${p}sticker  ${p}toimg  ${p}roubar       ║
║  ${p}ttp <texto>  ${p}attp <texto>  ║
╠══════════════════════════════════╣
║  🤖 *INTELIGÊNCIA ARTIFICIAL*    ║
║  ${p}ia  ${p}chat  ${p}gpt               ║
║  ${p}img <prompt>  ${p}tts <texto>  ║
╠══════════════════════════════════╣
║  📥 *DOWNLOADS*                  ║
║  ${p}play  ${p}ytmp3  ${p}ytmp4          ║
║  ${p}tiktok  ${p}instagram  ${p}facebook ║
╠══════════════════════════════════╣
║  🎮 *DIVERSÃO*                   ║
║  ${p}dado  ${p}cassino  ${p}roleta       ║
║  ${p}ppt  ${p}quiz  ${p}ship  ${p}casal    ║
║  ${p}rank  ${p}level  ${p}xp             ║
╠══════════════════════════════════╣
║  💰 *ECONOMIA*                   ║
║  ${p}saldo  ${p}daily  ${p}work          ║
║  ${p}transfer  ${p}bank               ║
╠══════════════════════════════════╣
║  🛠️ *UTILIDADES*                 ║
║  ${p}clima  ${p}hora  ${p}calc  ${p}cep   ║
║  ${p}traduz  ${p}google  ${p}wiki        ║
║  ${p}ping  ${p}info  ${p}postar          ║
╚══════════════════════════════════╝

⚡ Powered by *${ctx.config.botName}* 🤖`;
  await ctx.msg.reply(menu);
}

async function cmdHelp(ctx: CommandContext) {
  const cmd = ctx.args[0]?.toLowerCase();
  const helps: Record<string, string> = {
    ban: "🚫 !ban @user — Bane usuário do grupo. Requer admin.",
    kick: "👢 !kick @user — Remove usuário do grupo. Requer admin.",
    add: "➕ !add 5511999999999 — Adiciona número ao grupo.",
    promote: "⬆️ !promote @user — Promove a admin.",
    demote: "⬇️ !demote @user — Remove de admin.",
    mute: "🔇 !mute — Silencia o grupo (só admins falam).",
    unmute: "🔊 !unmute — Abre o grupo para todos.",
    grupo: "🔒 !grupo fechar | abrir — Fecha ou abre o grupo.",
    linkgp: "🔗 !linkgp — Mostra link de convite do grupo.",
    resetlink: "🔄 !resetlink — Reseta o link do grupo.",
    marcar: "📢 !marcar [mensagem] — Marca todos os membros.",
    hidetag: "👁️ !hidetag [mensagem] — Marca todos sem mostrar nomes.",
    sticker: "🎨 !sticker — Cria figurinha (responda ou envie mídia).",
    toimg: "🖼️ !toimg — Converte figurinha em imagem (responda).",
    ttp: "✏️ !ttp <texto> — Cria figurinha com texto.",
    attp: "🎭 !attp <texto> — Cria figurinha animada com texto.",
    roubar: "🎴 !roubar — Rouba figurinha de uma mensagem respondida.",
    ia: "🤖 !ia <pergunta> — Pergunta à IA.",
    img: "🎨 !img <prompt> — Gera imagem com IA.",
    tts: "🗣️ !tts <texto> — Converte texto em áudio.",
    dado: "🎲 !dado [lados] — Rola um dado. Ex: !dado 20",
    cassino: "🎰 !cassino <valor> — Joga no cassino.",
    roleta: "🎡 !roleta [aposta] — Joga na roleta.",
    ppt: "✂️ !ppt pedra|papel|tesoura — Joga contra o bot.",
    quiz: "❓ !quiz — Inicia uma pergunta de trivia.",
    ship: "💘 !ship @u1 @u2 — Calcula compatibilidade.",
    casal: "💑 !casal — Sorteia um casal no grupo.",
    rank: "🏆 !rank — Ranking de XP do grupo.",
    level: "⭐ !level — Seu nível e XP atual.",
    saldo: "💰 !saldo — Veja suas moedas.",
    daily: "📅 !daily — Colete recompensa diária.",
    work: "💼 !work — Trabalhe para ganhar moedas.",
    transfer: "💸 !transfer @user <valor> — Transfira moedas.",
    bank: "🏦 !bank depositar|sacar <valor> — Banco.",
    clima: "🌤️ !clima <cidade> — Clima atual.",
    hora: "🕐 !hora — Horário do Brasil.",
    calc: "🧮 !calc <expressão> — Calculadora.",
    cep: "📮 !cep <cep> — Consulta endereço por CEP.",
    traduz: "🌐 !traduz <texto> — Traduz para português.",
    google: "🔍 !google <pesquisa> — Link de pesquisa.",
    wiki: "📖 !wiki <termo> — Busca na Wikipedia.",
    ytmp3: "🎵 !ytmp3 <link> — Baixa áudio do YouTube.",
    ytmp4: "🎬 !ytmp4 <link> — Baixa vídeo do YouTube.",
    play: "▶️ !play <nome> — Busca e baixa música.",
    tiktok: "🎵 !tiktok <link> — Baixa vídeo do TikTok.",
    instagram: "📸 !instagram <link> — Baixa do Instagram.",
    facebook: "📘 !facebook <link> — Baixa do Facebook.",
    antispam: "🛡️ !antispam on/off — Ativa/desativa anti-spam.",
    antitrava: "🔒 !antitrava on/off — Ativa/desativa anti-trava.",
    antilink: "🔗 !antilink on/off — Ativa/desativa anti-link.",
    antifake: "👤 !antifake on/off — Ativa/desativa anti-fake.",
    antipalavrao: "🤬 !antipalavrao on/off — Ativa/desativa filtro de palavrões.",
    welcome: "👋 !welcome on [msg] [url] — Boas-vindas com mídia.",
  };
  if (cmd && helps[cmd]) {
    await ctx.msg.reply(`📖 *Ajuda — !${cmd}*\n\n${helps[cmd]}`);
  } else {
    await ctx.msg.reply(`❓ Use: !help <comando>\nEx: !help ban\n\nDigite !menu para ver todos os comandos.`);
  }
}

async function cmdIa(ctx: CommandContext) {
  if (!ctx.argString.trim()) {
    await ctx.msg.reply(`❓ Use: !ia <pergunta>\nEx: !ia Qual a capital do Brasil?`);
    return;
  }
  try {
    await ctx.chat.sendStateTyping();
    ctx.addLog("info", `🧠 IA: "${ctx.argString.substring(0, 60)}"`, ctx.contactName, ctx.isGroup);
    const response = await generateAIResponse(
      ctx.argString, ctx.contactName,
      ctx.isGroup ? ctx.chat.name : null,
      ctx.config.systemPrompt, ctx.config.botName,
    );
    await ctx.msg.reply(`🤖 *${ctx.config.botName}:*\n\n${response}`);
    await ctx.chat.clearState();
    addXp(ctx.senderId, 10);
    ctx.addLog("success", `✅ IA respondeu para ${ctx.contactName}`, ctx.contactName, ctx.isGroup);
  } catch (err) {
    await ctx.msg.reply("❌ Erro ao consultar a IA. Tente novamente!");
  }
}

async function cmdImg(ctx: CommandContext) {
  const prompt = ctx.argString.trim();
  if (!prompt) {
    await ctx.msg.reply("❓ Use: !img <descrição da imagem>\nEx: !img gato astronauta no espaço");
    return;
  }
  await ctx.msg.reply("🎨 Gerando imagem com IA... aguarde!");
  try {
    const url = await generateImage(prompt);
    if (!url) throw new Error("No URL");
    const media = await MessageMedia.fromUrl(url, { unsafeMime: true });
    await ctx.chat.sendMessage(media, { caption: `🖼️ *${prompt}*\n\n_Gerado por MÁRIO IA_ ✨` });
    ctx.addLog("success", `🖼️ Imagem gerada: "${prompt.substring(0, 40)}"`, ctx.contactName, ctx.isGroup);
  } catch (err) {
    await ctx.msg.reply("❌ Erro ao gerar imagem. Verifique se a IA está disponível.");
  }
}

async function cmdTts(ctx: CommandContext) {
  const text = ctx.argString.trim();
  if (!text) {
    await ctx.msg.reply("❓ Use: !tts <texto>\nEx: !tts Olá, eu sou o MÁRIO!");
    return;
  }
  await ctx.msg.reply("🗣️ Convertendo texto em áudio...");
  try {
    const audioBuffer = await generateTTS(text);
    if (!audioBuffer) throw new Error("No audio");
    const media = new MessageMedia("audio/mpeg", audioBuffer.toString("base64"), "audio.mp3");
    await ctx.chat.sendMessage(media, { sendAudioAsVoice: true });
  } catch {
    await ctx.msg.reply("❌ Erro ao gerar áudio. Tente novamente mais tarde.");
  }
}

async function cmdSticker(ctx: CommandContext) {
  let mediaMsg: Message | null = null;
  if (ctx.msg.hasQuotedMsg) {
    const quoted = await ctx.msg.getQuotedMessage();
    if (quoted.hasMedia) mediaMsg = quoted;
  } else if (ctx.msg.hasMedia) {
    mediaMsg = ctx.msg;
  }
  if (!mediaMsg) {
    await ctx.msg.reply("📎 *Como criar figurinha:*\n\n1. Envie imagem/vídeo/GIF com a legenda *!sticker*\n2. Ou responda uma mídia com *!sticker*");
    return;
  }
  try {
    await ctx.chat.sendStateTyping();
    const media = await mediaMsg.downloadMedia();
    if (!media?.data) { await ctx.msg.reply("❌ Não consegui baixar a mídia!"); return; }
    const buffer = await createSticker(media.data, media.mimetype);
    const stickerMedia = new MessageMedia("image/webp", buffer.toString("base64"), "sticker.webp");
    await ctx.chat.sendMessage(stickerMedia, { sendMediaAsSticker: true, stickerAuthor: "MÁRIO Bot", stickerName: "MÁRIO" });
    await ctx.chat.clearState();
    ctx.addLog("success", `🎨 Figurinha criada`, ctx.contactName, ctx.isGroup);
  } catch (err: any) {
    await ctx.msg.reply(`❌ Erro ao criar figurinha: ${err.message?.substring(0, 80)}`);
  }
}

async function cmdToimg(ctx: CommandContext) {
  if (!ctx.msg.hasQuotedMsg) {
    await ctx.msg.reply("❓ Responda uma *figurinha* com !toimg para convertê-la em imagem.");
    return;
  }
  const quoted = await ctx.msg.getQuotedMessage();
  if (!quoted.hasMedia) { await ctx.msg.reply("❌ A mensagem respondida não tem mídia!"); return; }
  try {
    const media = await quoted.downloadMedia();
    if (!media?.data) { await ctx.msg.reply("❌ Não consegui baixar a figurinha!"); return; }
    const imgBuffer = await stickerToImage(media.data);
    const imgMedia = new MessageMedia("image/png", imgBuffer.toString("base64"), "imagem.png");
    await ctx.chat.sendMessage(imgMedia, { caption: "🖼️ Figurinha convertida!" });
  } catch (err: any) {
    await ctx.msg.reply(`❌ Erro: ${err.message?.substring(0, 80)}`);
  }
}

async function cmdTtp(ctx: CommandContext) {
  const text = ctx.argString.trim();
  if (!text) { await ctx.msg.reply("❓ Use: !ttp <texto>\nEx: !ttp Olá mundo!"); return; }
  try {
    const buffer = await createTextSticker(text);
    const media = new MessageMedia("image/webp", buffer.toString("base64"), "sticker.webp");
    await ctx.chat.sendMessage(media, { sendMediaAsSticker: true, stickerAuthor: "MÁRIO Bot", stickerName: text });
  } catch (err: any) {
    await ctx.msg.reply(`❌ Erro: ${err.message?.substring(0, 80)}`);
  }
}

async function cmdAttp(ctx: CommandContext) {
  const text = ctx.argString.trim();
  if (!text) { await ctx.msg.reply("❓ Use: !attp <texto>\nEx: !attp MÁRIO BOT"); return; }
  const colors = ["#6c63ff", "#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff"];
  const bg = colors[Math.floor(Math.random() * colors.length)];
  try {
    const buffer = await createTextSticker(text, bg, "#ffffff");
    const media = new MessageMedia("image/webp", buffer.toString("base64"), "sticker.webp");
    await ctx.chat.sendMessage(media, { sendMediaAsSticker: true, stickerAuthor: "MÁRIO Bot", stickerName: text });
  } catch (err: any) {
    await ctx.msg.reply(`❌ Erro: ${err.message?.substring(0, 80)}`);
  }
}

async function cmdRoubar(ctx: CommandContext) {
  if (!ctx.msg.hasQuotedMsg) {
    await ctx.msg.reply("❓ Responda uma *figurinha* com !roubar para copiá-la.");
    return;
  }
  const quoted = await ctx.msg.getQuotedMessage();
  if (!quoted.hasMedia) { await ctx.msg.reply("❌ Responda uma figurinha!"); return; }
  try {
    const media = await quoted.downloadMedia();
    if (!media?.data) { await ctx.msg.reply("❌ Não consegui baixar a figurinha!"); return; }
    let stickerData = media.data;
    if (!media.mimetype.includes("webp")) {
      const buffer = await createSticker(media.data, media.mimetype);
      stickerData = buffer.toString("base64");
    }
    const stickerMedia = new MessageMedia("image/webp", stickerData, "sticker.webp");
    await ctx.chat.sendMessage(stickerMedia, { sendMediaAsSticker: true, stickerAuthor: "MÁRIO Bot", stickerName: "Roubada" });
  } catch (err: any) {
    await ctx.msg.reply(`❌ Erro ao roubar figurinha: ${err.message?.substring(0, 80)}`);
  }
}

async function cmdPostar(ctx: CommandContext) {
  let mediaMsg: Message | null = null;
  let caption = ctx.argString.trim();
  if (ctx.msg.hasMedia) {
    mediaMsg = ctx.msg;
  } else if (ctx.msg.hasQuotedMsg) {
    const quoted = await ctx.msg.getQuotedMessage();
    if (quoted.hasMedia) { mediaMsg = quoted; if (!caption && quoted.body) caption = quoted.body; }
  }
  if (!mediaMsg) {
    await ctx.msg.reply(`📢 *Como usar !postar:*\n\nEnvie foto/vídeo com legenda:\n_!postar Sua legenda aqui_`);
    return;
  }
  try {
    const media = await mediaMsg.downloadMedia();
    if (!media) { await ctx.msg.reply("❌ Não consegui baixar a mídia!"); return; }
    await ctx.chat.sendMessage(media, {
      caption: caption ? `${caption}\n\n_— ${ctx.config.botName}_` : `_Postado via ${ctx.config.botName}_`,
    });
    ctx.addLog("success", `📢 Mídia postada`, ctx.contactName, ctx.isGroup);
  } catch (err: any) {
    await ctx.msg.reply(`❌ Erro ao postar: ${err.message?.substring(0, 80)}`);
  }
}

export { checkQuizAnswer };

export const COMMANDS: Record<string, CommandHandler> = {
  menu: cmdMenu, ajuda: cmdMenu,
  help: cmdHelp,
  ia: cmdIa, chat: cmdIa, gpt: cmdIa,
  img: cmdImg, imagem: cmdImg,
  tts: cmdTts, voz: cmdTts,
  sticker: cmdSticker, s: cmdSticker, figurinha: cmdSticker,
  toimg: cmdToimg,
  ttp: cmdTtp,
  attp: cmdAttp,
  roubar: cmdRoubar,
  ban: cmdBan, kick: cmdKick,
  add: cmdAdd,
  promote: cmdPromote, promover: cmdPromote,
  demote: cmdDemote, rebaixar: cmdDemote,
  mute: cmdMute, mutar: cmdMute,
  unmute: cmdUnmute,
  grupo: cmdGrupo,
  linkgp: cmdLinkgp, link: cmdLinkgp,
  resetlink: cmdResetlink,
  marcar: cmdMarcar, tagall: cmdMarcar,
  hidetag: cmdHidetag,
  antispam: cmdAntispam,
  antitrava: cmdAntitrava,
  antilink: cmdAntilink,
  antifake: cmdAntifake,
  antipalavrao: cmdAntipalavrao,
  welcome: cmdWelcome, boasvindas: cmdWelcome,
  // ── Moderação avançada ────────────────────────────────────────────────
  antivirus: cmdAntivirus,
  antiimagem: cmdAntiimagem,
  antiaudio: cmdAntiaudio,
  antilocalizacao: cmdAntilocalizacao,
  antilinkdegrupowhatsapp: cmdAntilinkgp, antilinkgp: cmdAntilinkgp,
  antigif: cmdAntigif,
  antifigurinha: cmdAntifigurinha,
  antipalavraomod: cmdAntipalavraomod,
  antipalavraoaudio: cmdAntipalavraoaudio,
  antipalavraovideo: cmdAntipalavraovideo,
  antipornografiatexto: cmdAntipornografiatexto,
  antipornografiaimagem: cmdAntipornografiaimagem,
  antipornografiavideo: cmdAntipornografiavideo,
  antipornografiaaudio: cmdAntipornografiaaudio,
  antipornografiagif: cmdAntipornografiagif,
  antifigurinhapornografica: cmdAntifigurinhapornografica,
  autofig: cmdAutofig,
  // ── Sistema de advertências ────────────────────────────────────────────
  setadv: cmdSetadv,
  resetadv: cmdResetadv,
  adv: cmdAdv, avisos: cmdAdv,
  // ── Agendamento ───────────────────────────────────────────────────────
  fechargp: cmdFechargp,
  abrirgp: cmdAbrirgp,
  agendamentos: cmdAgendamentos, agenda: cmdAgendamentos,
  cancedag: cmdCancelarAg,
  // ── Status de moderação ────────────────────────────────────────────────
  modstatus: cmdModstatus, moderacao: cmdModstatus,
  // ── Globais ───────────────────────────────────────────────────────────
  ativartodos: cmdAtivartodos, ligartodos: cmdAtivartodos, protecaomaxima: cmdAtivartodos,
  desativartodos: cmdDesativartodos, desligartodos: cmdDesativartodos,
  rank: cmdRank, ranking: cmdRank,
  level: cmdLevel, nivel: cmdLevel,
  xp: cmdXp,
  dado: cmdDado, dice: cmdDado,
  cassino: cmdCassino, casino: cmdCassino,
  roleta: cmdRoleta,
  ppt: cmdPpt, rps: cmdPpt,
  quiz: cmdQuiz,
  ship: cmdShip,
  casal: cmdCasal,
  saldo: cmdSaldo, carteira: cmdSaldo,
  daily: cmdDaily, diario: cmdDaily,
  work: cmdWork, trabalhar: cmdWork,
  transfer: cmdTransfer, transferir: cmdTransfer,
  bank: cmdBank, banco: cmdBank,
  clima: cmdClima, tempo: cmdClima,
  hora: cmdHora, horas: cmdHora,
  calc: cmdCalc, calcular: cmdCalc,
  cep: cmdCep,
  traduz: cmdTraduz, traduzir: cmdTraduz,
  google: cmdGoogle,
  wiki: cmdWiki, wikipedia: cmdWiki,
  ping: cmdPing,
  info: cmdInfo,
  postar: cmdPostar, post: cmdPostar,
  play: cmdPlay,
  ytmp3: cmdYtmp3, mp3: cmdYtmp3,
  ytmp4: cmdYtmp4, mp4: cmdYtmp4,
  tiktok: cmdTiktok, tt: cmdTiktok,
  instagram: cmdInstagram, ig: cmdInstagram, insta: cmdInstagram,
  facebook: cmdFacebook, fb: cmdFacebook,
};

export async function handleCommand(
  prefix: string,
  body: string,
  ctx: Omit<CommandContext, "args" | "argString">,
): Promise<boolean> {
  if (!body.startsWith(prefix)) return false;
  const withoutPrefix = body.slice(prefix.length).trim();
  const parts = withoutPrefix.split(/\s+/);
  const commandName = parts[0]?.toLowerCase();
  const args = parts.slice(1);
  const argString = parts.slice(1).join(" ");
  if (!commandName) return false;
  const handler = COMMANDS[commandName];
  if (!handler) {
    await ctx.msg.reply(
      `❓ Comando *${prefix}${commandName}* não encontrado.\nDigite *${prefix}menu* para ver todos os comandos.`,
    );
    return true;
  }
  try {
    addXp(ctx.senderId, 5);
    await handler({ ...ctx, args, argString });
  } catch (err) {
    logger.error({ err, commandName }, "Command handler error");
    await ctx.msg.reply(`❌ Erro interno no comando *${prefix}${commandName}*. Tente novamente!`);
  }
  return true;
}
