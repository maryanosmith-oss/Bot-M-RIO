import { CommandContext } from "../commands";

export async function cmdHora(ctx: CommandContext) {
  const now = new Date();
  const br = now.toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });
  const utc = now.toUTCString();
  await ctx.msg.reply(`🕐 *Horário atual:*\n\n🇧🇷 Brasil (SP): ${br}\n🌍 UTC: ${utc}`);
}

export async function cmdCalc(ctx: CommandContext) {
  const expr = ctx.argString.trim();
  if (!expr) {
    await ctx.msg.reply("❓ Use: !calc <expressão>\nEx: !calc 2 + 2 * 10");
    return;
  }
  try {
    const sanitized = expr.replace(/[^0-9+\-*/.%() ]/g, "");
    // eslint-disable-next-line no-new-func
    const result = Function(`"use strict"; return (${sanitized})`)();
    await ctx.msg.reply(`🧮 *Calculadora:*\n\n${expr}\n= *${result}*`);
  } catch {
    await ctx.msg.reply("❌ Expressão inválida! Ex: !calc 10 * 5 + 2");
  }
}

export async function cmdCep(ctx: CommandContext) {
  const cep = ctx.args[0]?.replace(/[^0-9]/g, "");
  if (!cep || cep.length !== 8) {
    await ctx.msg.reply("❓ Use: !cep 01310100\n(Somente números, 8 dígitos)");
    return;
  }
  try {
    const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const data = (await res.json()) as any;
    if (data.erro) {
      await ctx.msg.reply("❌ CEP não encontrado!");
      return;
    }
    await ctx.msg.reply(
      `📮 *CEP: ${cep}*\n\n📍 Logradouro: ${data.logradouro || "-"}\n🏘️ Bairro: ${data.bairro || "-"}\n🏙️ Cidade: ${data.localidade || "-"}\n🗺️ Estado: ${data.uf || "-"}`,
    );
  } catch {
    await ctx.msg.reply("❌ Erro ao consultar o CEP. Tente novamente.");
  }
}

export async function cmdClima(ctx: CommandContext) {
  const city = ctx.argString.trim().replace(/ /g, "+");
  if (!city) {
    await ctx.msg.reply("❓ Use: !clima <cidade>\nEx: !clima São Paulo");
    return;
  }
  try {
    const res = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1&lang=pt`);
    const data = (await res.json()) as any;
    const current = data.current_condition?.[0];
    const area = data.nearest_area?.[0];
    if (!current) throw new Error("No data");
    const temp = current.temp_C;
    const feels = current.FeelsLikeC;
    const desc = current.lang_pt?.[0]?.value || current.weatherDesc?.[0]?.value || "";
    const humidity = current.humidity;
    const wind = current.windspeedKmph;
    const place = area?.areaName?.[0]?.value || city;

    await ctx.msg.reply(
      `🌤️ *Clima em ${place}:*\n\n🌡️ Temperatura: ${temp}°C (sente ${feels}°C)\n☁️ Condição: ${desc}\n💧 Umidade: ${humidity}%\n💨 Vento: ${wind} km/h`,
    );
  } catch {
    await ctx.msg.reply(`❌ Não encontrei o clima de "${ctx.argString}". Verifique o nome da cidade.`);
  }
}

export async function cmdTraduz(ctx: CommandContext) {
  const text = ctx.argString.trim();
  if (!text) {
    await ctx.msg.reply("❓ Use: !traduz <texto em qualquer idioma>\nEx: !traduz Hello world");
    return;
  }
  try {
    const encoded = encodeURIComponent(text);
    const res = await fetch(
      `https://api.mymemory.translated.net/get?q=${encoded}&langpair=auto|pt-br`,
    );
    const data = (await res.json()) as any;
    const translated = data.responseData?.translatedText;
    if (!translated) throw new Error("No translation");
    await ctx.msg.reply(`🌐 *Tradução:*\n\n"${text}"\n\n▶️ "${translated}"`);
  } catch {
    await ctx.msg.reply("❌ Erro ao traduzir. Tente novamente.");
  }
}

export async function cmdWiki(ctx: CommandContext) {
  const term = ctx.argString.trim();
  if (!term) {
    await ctx.msg.reply("❓ Use: !wiki <termo>\nEx: !wiki Inteligência Artificial");
    return;
  }
  try {
    const encoded = encodeURIComponent(term);
    const res = await fetch(
      `https://pt.wikipedia.org/api/rest_v1/page/summary/${encoded}`,
    );
    const data = (await res.json()) as any;
    if (data.type === "disambiguation" || !data.extract) {
      await ctx.msg.reply(`❓ Página "${term}" é ambígua. Seja mais específico.`);
      return;
    }
    const extract = data.extract.substring(0, 600) + (data.extract.length > 600 ? "..." : "");
    await ctx.msg.reply(
      `📖 *Wikipedia — ${data.title}*\n\n${extract}\n\n🔗 ${data.content_urls?.desktop?.page || ""}`,
    );
  } catch {
    await ctx.msg.reply(`❌ Não encontrei informações sobre "${term}".`);
  }
}

export async function cmdGoogle(ctx: CommandContext) {
  const query = ctx.argString.trim();
  if (!query) {
    await ctx.msg.reply("❓ Use: !google <pesquisa>\nEx: !google como fazer bolo");
    return;
  }
  const encoded = encodeURIComponent(query);
  await ctx.msg.reply(
    `🔍 *Pesquisa no Google:*\n\n"${query}"\n\n🔗 https://www.google.com/search?q=${encoded}`,
  );
}

export async function cmdPing(ctx: CommandContext) {
  const start = Date.now();
  await ctx.msg.reply("🏓 Pong!");
  const ms = Date.now() - start;
  await ctx.msg.reply(`⚡ Latência: *${ms}ms* | Bot *${ctx.config.botName}* online! ✅`);
}

export async function cmdInfo(ctx: CommandContext) {
  if (!ctx.isGroup) {
    const contact = await ctx.msg.getContact();
    await ctx.msg.reply(
      `📋 *Informações:*\n\n👤 Nome: ${contact.pushname || contact.name || "?"}\n📱 Número: ${contact.number}`,
    );
    return;
  }
  const group = ctx.chat as any;
  const participants = group.participants || [];
  const admins = participants.filter((p: any) => p.isAdmin);
  await ctx.msg.reply(
    `📋 *Info do Grupo:*\n\n👥 Nome: ${group.name}\n👤 Membros: ${participants.length}\n👑 Admins: ${admins.length}\n📅 Criado: ${new Date((group.createdAt || 0) * 1000).toLocaleDateString("pt-BR")}`,
  );
}
