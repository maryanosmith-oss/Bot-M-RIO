import { CommandContext } from "../commands";
import { getUser, saveUser } from "../db";

const WORK_JOBS = [
  "programador", "designer", "motorista", "médico", "professor",
  "chef", "engenheiro", "veterinário", "jornalista", "músico",
];

export async function cmdSaldo(ctx: CommandContext) {
  const user = getUser(ctx.senderId);
  await ctx.msg.reply(
    `💰 *Carteira de ${ctx.contactName}:*\n\n🪙 Carteira: ${user.coins}\n🏦 Banco: ${user.bank}\n💎 Total: ${user.coins + user.bank}\n\n⭐ Nível: ${user.level} | XP: ${user.xp}`,
  );
}

export async function cmdDaily(ctx: CommandContext) {
  const user = getUser(ctx.senderId);
  const now = Date.now();
  const cooldown = 24 * 60 * 60 * 1000;
  if (now - user.lastDaily < cooldown) {
    const next = new Date(user.lastDaily + cooldown);
    const h = Math.floor((user.lastDaily + cooldown - now) / 3600000);
    const m = Math.floor(((user.lastDaily + cooldown - now) % 3600000) / 60000);
    await ctx.msg.reply(`⏳ Você já coletou seu daily!\nPróximo em: *${h}h ${m}min*`);
    return;
  }
  const reward = Math.floor(Math.random() * 400) + 100;
  user.coins += reward;
  user.lastDaily = now;
  saveUser(user);
  await ctx.msg.reply(
    `✅ *Daily coletado!*\n\n🪙 +${reward} moedas!\nSaldo: ${user.coins} 🪙\n\nVolte amanhã para mais recompensas!`,
  );
}

export async function cmdWork(ctx: CommandContext) {
  const user = getUser(ctx.senderId);
  const now = Date.now();
  const cooldown = 60 * 60 * 1000;
  if (now - user.lastWork < cooldown) {
    const min = Math.floor((user.lastWork + cooldown - now) / 60000);
    await ctx.msg.reply(`⏳ Você já trabalhou hoje! Descanse mais *${min} minutos*.`);
    return;
  }
  const job = WORK_JOBS[Math.floor(Math.random() * WORK_JOBS.length)];
  const reward = Math.floor(Math.random() * 150) + 50;
  user.coins += reward;
  user.lastWork = now;
  saveUser(user);
  await ctx.msg.reply(
    `💼 *Trabalho concluído!*\n\nVocê trabalhou como *${job}* e ganhou:\n🪙 +${reward} moedas!\nSaldo: ${user.coins} 🪙`,
  );
}

export async function cmdTransfer(ctx: CommandContext) {
  const mentions = await ctx.msg.getMentions();
  const amount = parseInt(ctx.args[mentions.length > 0 ? 0 : 1]) || 0;
  
  if (!mentions.length && !ctx.args[0]) {
    await ctx.msg.reply("❓ Use: !transfer @usuario <valor>\nEx: !transfer @joao 100");
    return;
  }
  
  if (amount <= 0) {
    await ctx.msg.reply("❌ Valor inválido! Use um número positivo.");
    return;
  }

  const sender = getUser(ctx.senderId);
  if (sender.coins < amount) {
    await ctx.msg.reply(`❌ Saldo insuficiente! Você tem: ${sender.coins} 🪙`);
    return;
  }

  const target = mentions[0];
  if (!target) {
    await ctx.msg.reply("❓ Marque o usuário: !transfer @usuario 100");
    return;
  }

  const targetUser = getUser(target.id._serialized);
  sender.coins -= amount;
  targetUser.coins += amount;
  saveUser(sender);
  saveUser(targetUser);

  await ctx.msg.reply(
    `✅ *Transferência realizada!*\n\n💸 ${ctx.contactName} → ${target.pushname || target.number}\n🪙 Valor: ${amount}\n\nSeu saldo: ${sender.coins} 🪙`,
  );
}

export async function cmdBank(ctx: CommandContext) {
  const action = ctx.args[0]?.toLowerCase();
  const amount = parseInt(ctx.args[1]) || 0;
  const user = getUser(ctx.senderId);

  if (action === "depositar" || action === "dep") {
    if (amount <= 0 || amount > user.coins) {
      await ctx.msg.reply(`❌ Valor inválido! Carteira: ${user.coins} 🪙`);
      return;
    }
    user.coins -= amount;
    user.bank += amount;
    saveUser(user);
    await ctx.msg.reply(`🏦 Depositado *${amount}* 🪙!\nCarteira: ${user.coins} | Banco: ${user.bank}`);
  } else if (action === "sacar" || action === "saq") {
    if (amount <= 0 || amount > user.bank) {
      await ctx.msg.reply(`❌ Valor inválido! Banco: ${user.bank} 🪙`);
      return;
    }
    user.bank -= amount;
    user.coins += amount;
    saveUser(user);
    await ctx.msg.reply(`🏦 Sacado *${amount}* 🪙!\nCarteira: ${user.coins} | Banco: ${user.bank}`);
  } else {
    await ctx.msg.reply(
      `🏦 *Banco de ${ctx.contactName}:*\n\n🪙 Carteira: ${user.coins}\n🏦 Banco: ${user.bank}\n\n📥 !bank depositar <valor>\n📤 !bank sacar <valor>`,
    );
  }
}
