import { CommandContext } from "../commands";
import { getUser, saveUser, addXp, getLeaderboard } from "../db";

const QUIZ_QUESTIONS = [
  { q: "🌎 Qual é a capital do Brasil?", a: "brasília", hint: "Começa com B" },
  { q: "⚽ Quantas copas do mundo o Brasil tem?", a: "5", hint: "É o maior campeão" },
  { q: "🔢 Qual é a raiz quadrada de 144?", a: "12", hint: "É uma dúzia" },
  { q: "🌊 Qual é o maior oceano do mundo?", a: "pacífico", hint: "Começa com P" },
  { q: "🦁 Qual é o animal mais rápido do mundo?", a: "guepardo", hint: "É um felino africano" },
  { q: "💻 Quem criou o Python?", a: "guido", hint: "Nome holandês" },
  { q: "🎵 Qual é o instrumento símbolo do Brasil?", a: "cavaquinho", hint: "Parece um violão pequeno" },
  { q: "🌡️ A que temperatura a água ferve?", a: "100", hint: "Três dígitos iguais" },
  { q: "🌙 Quantas luas a Terra tem?", a: "1", hint: "Só uma" },
  { q: "🎮 Qual personagem da Nintendo pula em cima de inimigos?", a: "mario", hint: "É o nosso bot!" },
];

const activeQuizzes = new Map<string, { q: string; a: string; ts: number }>();
const cooldowns = new Map<string, number>();

function checkCooldown(key: string, seconds: number): number {
  const last = cooldowns.get(key) || 0;
  const remaining = Math.ceil((last + seconds * 1000 - Date.now()) / 1000);
  return remaining > 0 ? remaining : 0;
}

function setCooldown(key: string) {
  cooldowns.set(key, Date.now());
}

export async function cmdRank(ctx: CommandContext) {
  const top = getLeaderboard();
  if (!top.length) {
    await ctx.msg.reply("📊 Nenhum usuário no ranking ainda!");
    return;
  }
  const medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];
  const lines = top.map((u, i) => `${medals[i] || `${i + 1}.`} ${u.id.split("@")[0]} — Nível ${u.level} | ${u.xp} XP`);
  await ctx.msg.reply(`🏆 *RANKING GLOBAL:*\n\n${lines.join("\n")}`);
}

export async function cmdLevel(ctx: CommandContext) {
  const user = getUser(ctx.senderId);
  const xpNext = ((user.level) * user.level) * 50;
  await ctx.msg.reply(
    `📊 *Seus Stats:*\n\n👤 ${ctx.contactName}\n⭐ Nível: ${user.level}\n✨ XP: ${user.xp}/${xpNext}\n💬 Mensagens: ${user.totalMessages}`,
  );
}

export async function cmdXp(ctx: CommandContext) {
  return cmdLevel(ctx);
}

export async function cmdDado(ctx: CommandContext) {
  const sides = parseInt(ctx.args[0]) || 6;
  const validSides = Math.max(2, Math.min(100, sides));
  const result = Math.floor(Math.random() * validSides) + 1;
  await ctx.msg.reply(`🎲 Dado de ${validSides} faces: *${result}*`);
}

export async function cmdCassino(ctx: CommandContext) {
  const user = getUser(ctx.senderId);
  const aposta = parseInt(ctx.args[0]) || 0;
  if (aposta <= 0) {
    await ctx.msg.reply("❓ Use: !cassino <valor>\nEx: !cassino 100");
    return;
  }
  if (aposta > user.coins) {
    await ctx.msg.reply(`❌ Você não tem moedas suficientes! Saldo: ${user.coins} 🪙`);
    return;
  }
  const cd = checkCooldown(`cassino_${ctx.senderId}`, 10);
  if (cd) {
    await ctx.msg.reply(`⏳ Aguarde ${cd}s para jogar novamente!`);
    return;
  }
  setCooldown(`cassino_${ctx.senderId}`);

  const roll = Math.random();
  const slots = ["🍒", "🍋", "🍊", "⭐", "💎", "7️⃣"];
  const s1 = slots[Math.floor(Math.random() * slots.length)];
  const s2 = slots[Math.floor(Math.random() * slots.length)];
  const s3 = slots[Math.floor(Math.random() * slots.length)];

  let msg = `🎰 [ ${s1} | ${s2} | ${s3} ]\n\n`;
  if (s1 === s2 && s2 === s3) {
    const ganho = aposta * 3;
    user.coins += ganho;
    msg += `🎉 *JACKPOT!* Você ganhou *${ganho}* 🪙!\nNovo saldo: ${user.coins} 🪙`;
  } else if (s1 === s2 || s2 === s3 || s1 === s3) {
    const ganho = Math.floor(aposta * 1.5);
    user.coins += ganho - aposta;
    msg += `✨ *Dois iguais!* Ganhou *${ganho}* 🪙!\nNovo saldo: ${user.coins} 🪙`;
  } else if (roll < 0.4) {
    const ganho = Math.floor(aposta * 2);
    user.coins += ganho - aposta;
    msg += `🎊 *Ganhou!* +${ganho - aposta} 🪙!\nNovo saldo: ${user.coins} 🪙`;
  } else {
    user.coins -= aposta;
    msg += `😢 *Perdeu!* -${aposta} 🪙\nNovo saldo: ${user.coins} 🪙`;
  }
  saveUser(user);
  await ctx.msg.reply(msg);
}

export async function cmdRoleta(ctx: CommandContext) {
  const user = getUser(ctx.senderId);
  const aposta = parseInt(ctx.args[0]) || 50;
  if (aposta > user.coins) {
    await ctx.msg.reply(`❌ Saldo insuficiente! Você tem: ${user.coins} 🪙`);
    return;
  }
  const numero = Math.floor(Math.random() * 37);
  const cor = numero === 0 ? "🟢" : numero % 2 === 0 ? "🔴" : "⚫";
  const ganhou = Math.random() < 0.45;
  if (ganhou) {
    user.coins += aposta;
    await ctx.msg.reply(`🎡 Roleta: ${cor} *${numero}*\n🎉 Ganhou! +${aposta} 🪙\nSaldo: ${user.coins} 🪙`);
  } else {
    user.coins -= aposta;
    await ctx.msg.reply(`🎡 Roleta: ${cor} *${numero}*\n😢 Perdeu! -${aposta} 🪙\nSaldo: ${user.coins} 🪙`);
  }
  saveUser(user);
}

export async function cmdPpt(ctx: CommandContext) {
  const choices = ["pedra", "papel", "tesoura"];
  const emojis: Record<string, string> = { pedra: "🪨", papel: "📄", tesoura: "✂️" };
  const botChoice = choices[Math.floor(Math.random() * choices.length)];
  const userChoice = ctx.args[0]?.toLowerCase();

  if (!choices.includes(userChoice)) {
    await ctx.msg.reply("❓ Use: !ppt pedra | papel | tesoura");
    return;
  }

  let result = "Empate! 🤝";
  if (
    (userChoice === "pedra" && botChoice === "tesoura") ||
    (userChoice === "papel" && botChoice === "pedra") ||
    (userChoice === "tesoura" && botChoice === "papel")
  ) {
    result = "Você *GANHOU*! 🎉";
    const user = getUser(ctx.senderId);
    user.coins += 20;
    saveUser(user);
  } else if (userChoice !== botChoice) {
    result = "Bot *GANHOU*! 🤖";
  }

  await ctx.msg.reply(
    `${emojis[userChoice]} vs ${emojis[botChoice]}\n\n${result}`,
  );
}

export async function cmdQuiz(ctx: CommandContext) {
  const chatId = ctx.chat.id._serialized;
  const existing = activeQuizzes.get(chatId);
  if (existing && Date.now() - existing.ts < 30000) {
    await ctx.msg.reply("⏳ Há um quiz ativo! Responda a pergunta atual antes de pedir outro.");
    return;
  }
  const q = QUIZ_QUESTIONS[Math.floor(Math.random() * QUIZ_QUESTIONS.length)];
  activeQuizzes.set(chatId, { q: q.q, a: q.a, ts: Date.now() });

  await ctx.msg.reply(
    `🎯 *QUIZ!*\n\n${q.q}\n\n💡 Dica: ${q.hint}\n\n⏱️ 30 segundos para responder!`,
  );

  setTimeout(() => {
    const still = activeQuizzes.get(chatId);
    if (still && still.ts === q.ts) {
      activeQuizzes.delete(chatId);
      ctx.chat.sendMessage(`⏰ Tempo esgotado! A resposta era: *${q.a}*`);
    }
  }, 30000);
}

export function checkQuizAnswer(chatId: string, answer: string): string | null {
  const quiz = activeQuizzes.get(chatId);
  if (!quiz) return null;
  if (answer.toLowerCase().includes(quiz.a.toLowerCase())) {
    activeQuizzes.delete(chatId);
    return quiz.a;
  }
  return null;
}

export async function cmdShip(ctx: CommandContext) {
  const mentions = await ctx.msg.getMentions();
  const names =
    mentions.length >= 2
      ? [mentions[0].pushname || mentions[0].number, mentions[1].pushname || mentions[1].number]
      : ctx.args.length >= 2
      ? [ctx.args[0], ctx.args[1]]
      : null;

  if (!names) {
    await ctx.msg.reply("❓ Use: !ship @pessoa1 @pessoa2 ou !ship Nome1 Nome2");
    return;
  }

  const pct = Math.floor(Math.random() * 101);
  const bar = "█".repeat(Math.floor(pct / 10)) + "░".repeat(10 - Math.floor(pct / 10));
  const emoji =
    pct >= 80 ? "💘" : pct >= 60 ? "💕" : pct >= 40 ? "💙" : pct >= 20 ? "💛" : "💔";

  await ctx.msg.reply(
    `💘 *SHIP METER*\n\n${names[0]} + ${names[1]}\n\n${emoji} [${bar}] ${pct}%\n\n${pct >= 80 ? "❤️ Amor verdadeiro!" : pct >= 50 ? "😊 Boa combinação!" : pct >= 30 ? "🤔 Pode funcionar..." : "😅 Talvez não seja o destino..."}`,
  );
}

export async function cmdCasal(ctx: CommandContext) {
  const group = ctx.isGroup ? (ctx.chat as any) : null;
  if (!group) {
    await ctx.msg.reply("❌ Só funciona em grupos!");
    return;
  }
  const participants = group.participants || [];
  if (participants.length < 2) {
    await ctx.msg.reply("❌ Poucas pessoas no grupo!");
    return;
  }
  const p1 = participants[Math.floor(Math.random() * participants.length)];
  let p2 = participants[Math.floor(Math.random() * participants.length)];
  while (p2.id._serialized === p1.id._serialized) {
    p2 = participants[Math.floor(Math.random() * participants.length)];
  }
  const pct = Math.floor(Math.random() * 101);
  await ctx.msg.reply(
    `💑 *CASAL DO DIA*\n\n@${p1.id.user} + @${p2.id.user}\n\n💕 Compatibilidade: ${pct}%\n\n${pct >= 70 ? "❤️ Perfeitos um para o outro!" : "💛 Podem se conhecer melhor!"}`,
    { mentions: [p1.id._serialized, p2.id._serialized] as any },
  );
}
