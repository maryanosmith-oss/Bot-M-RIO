import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { BotConfig } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2, Save, Settings2 } from "lucide-react";

const configSchema = z.object({
  botName: z.string().min(1, "O nome do bot é obrigatório"),
  systemPrompt: z.string().min(10, "O prompt deve ter pelo menos 10 caracteres"),
  replyInGroups: z.boolean(),
  antiSpamDelay: z.coerce.number().min(0, "O delay não pode ser negativo"),
  responseDelay: z.coerce.number().min(0, "O delay não pode ser negativo"),
  prefix: z.string().min(1, "O prefixo é obrigatório").max(3, "Máximo de 3 caracteres"),
  mode: z.enum(["commands", "auto", "both"]),
});

export type ConfigFormValues = z.infer<typeof configSchema>;

export function ConfigWidget({ 
  config, 
  onSave, 
  isPending 
}: { 
  config?: BotConfig; 
  onSave: (data: ConfigFormValues) => void;
  isPending: boolean;
}) {
  const form = useForm<ConfigFormValues>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      botName: "",
      systemPrompt: "",
      replyInGroups: false,
      antiSpamDelay: 3000,
      responseDelay: 1500,
      prefix: "!",
      mode: "both",
    }
  });

  // Reset form when fresh config arrives
  useEffect(() => {
    if (config) {
      form.reset({
        botName: config.botName,
        systemPrompt: config.systemPrompt,
        replyInGroups: config.replyInGroups,
        antiSpamDelay: config.antiSpamDelay,
        responseDelay: config.responseDelay,
        prefix: config.prefix || "!",
        mode: (config.mode as "commands" | "auto" | "both") || "both",
      });
    }
  }, [config, form]);

  return (
    <Card className="border-border/50 shadow-xl bg-card/60 backdrop-blur-md">
      <CardHeader className="border-b border-border/50 pb-4">
        <CardTitle className="text-xl font-display flex items-center gap-2">
          <Settings2 className="w-5 h-5 text-primary" />
          Configurações de Personalidade
        </CardTitle>
        <CardDescription>
          Ajuste como o MÁRIO se comporta e responde aos usuários.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
            
            <FormField
              control={form.control}
              name="mode"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Modo de Operação</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      value={field.value}
                      className="grid grid-cols-1 sm:grid-cols-3 gap-3"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0 rounded-xl border border-border/50 bg-background/50 p-4 transition-colors hover:border-border cursor-pointer [&:has([data-state=checked])]:border-primary/50 [&:has([data-state=checked])]:bg-primary/5">
                        <FormControl>
                          <RadioGroupItem value="commands" />
                        </FormControl>
                        <FormLabel className="font-medium cursor-pointer flex-1 text-sm">
                          🔧 Comandos (!)
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0 rounded-xl border border-border/50 bg-background/50 p-4 transition-colors hover:border-border cursor-pointer [&:has([data-state=checked])]:border-primary/50 [&:has([data-state=checked])]:bg-primary/5">
                        <FormControl>
                          <RadioGroupItem value="auto" />
                        </FormControl>
                        <FormLabel className="font-medium cursor-pointer flex-1 text-sm">
                          🤖 Auto-resposta
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0 rounded-xl border border-border/50 bg-background/50 p-4 transition-colors hover:border-border cursor-pointer [&:has([data-state=checked])]:border-primary/50 [&:has([data-state=checked])]:bg-primary/5">
                        <FormControl>
                          <RadioGroupItem value="both" />
                        </FormControl>
                        <FormLabel className="font-medium cursor-pointer flex-1 text-sm">
                          ⚡ Comandos + Auto
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="botName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome do Bot</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Ex: MÁRIO" 
                        {...field} 
                        className="bg-background/50 border-border/50 focus:border-primary focus:ring-primary/20 transition-all" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="prefix"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prefixo de Comando</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Ex: !" 
                        {...field} 
                        className="bg-background/50 border-border/50 focus:border-primary focus:ring-primary/20 transition-all font-mono" 
                        maxLength={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="antiSpamDelay"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Delay Anti-Spam (ms)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        className="bg-background/50 border-border/50 focus:border-primary focus:ring-primary/20 transition-all" 
                      />
                    </FormControl>
                    <FormDescription>Tempo mínimo entre mensagens.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="responseDelay"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Delay de Digitação (ms)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        className="bg-background/50 border-border/50 focus:border-primary focus:ring-primary/20 transition-all" 
                      />
                    </FormControl>
                    <FormDescription>Simula tempo de digitação.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="systemPrompt"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Prompt de Sistema (IA)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Você é um assistente virtual amigável..." 
                      className="min-h-[120px] resize-none bg-background/50 border-border/50 focus:border-primary focus:ring-primary/20 transition-all" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Instruções que definem a personalidade e regras do bot.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="replyInGroups"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-xl border border-border/50 bg-background/50 p-4 transition-colors hover:border-border">
                  <div className="space-y-0.5">
                    <FormLabel className="text-sm font-medium">Responder em Grupos</FormLabel>
                    <FormDescription className="text-xs">
                      O MÁRIO responderá a mensagens em chats de grupo.
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      className="data-[state=checked]:bg-primary"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="pt-4 flex justify-end">
              <Button 
                type="submit" 
                disabled={isPending} 
                className="w-full sm:w-auto px-8 py-6 rounded-xl font-semibold bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
              >
                {isPending ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  <Save className="mr-2 h-5 w-5" />
                )}
                Salvar Configurações
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}