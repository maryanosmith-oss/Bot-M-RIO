import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { QrCode } from "lucide-react";

export function QrWidget({ qrDataUrl }: { qrDataUrl: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      <Card className="border-primary/30 shadow-2xl shadow-primary/10 bg-card/80 backdrop-blur-md relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
        
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-xl font-display flex items-center justify-center gap-2">
            <QrCode className="w-6 h-6 text-primary" />
            Conectar WhatsApp
          </CardTitle>
          <CardDescription className="text-sm">
            Abra o WhatsApp &gt; Menu &gt; Aparelhos conectados &gt; Conectar um aparelho
          </CardDescription>
        </CardHeader>
        
        <CardContent className="flex flex-col items-center justify-center py-8">
          <div className="bg-white p-4 rounded-2xl shadow-[0_0_30px_rgba(37,211,102,0.15)] relative group">
            <img 
              src={qrDataUrl} 
              className="w-64 h-64 object-contain transition-transform duration-300 group-hover:scale-[1.02]" 
              alt="WhatsApp QR Code" 
            />
            {/* Holographic scanner line animation */}
            <motion.div 
              animate={{ top: ["0%", "100%", "0%"] }} 
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="absolute left-0 right-0 h-[2px] bg-primary shadow-[0_0_12px_3px_rgba(37,211,102,0.8)] z-10 opacity-70" 
            />
          </div>
          <p className="mt-6 text-sm text-muted-foreground animate-pulse text-center max-w-[250px]">
            Aguardando escaneamento... O código é atualizado automaticamente.
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}
