import { useQueryClient } from "@tanstack/react-query";
import {
  useGetBotStatus,
  useGetBotQr,
  useGetBotLogs,
  useGetBotConfig,
  useUpdateBotConfig,
  useDisconnectBot,
  getGetBotConfigQueryKey,
  getGetBotStatusQueryKey,
  getGetBotLogsQueryKey,
} from "@workspace/api-client-react";

export function useBot() {
  const queryClient = useQueryClient();

  // Poll status every 5 seconds
  const status = useGetBotStatus({
    query: { refetchInterval: 5000 },
  });

  const isQrReady = status.data?.state === "qr_ready";

  // Poll QR code every 3 seconds only when the bot is waiting for a scan
  const qr = useGetBotQr({
    query: {
      refetchInterval: isQrReady ? 3000 : false,
      enabled: isQrReady,
    },
  });

  // Poll logs every 5 seconds
  const logs = useGetBotLogs({
    query: { refetchInterval: 5000 },
  });

  // Fetch config once, can be invalidated on update
  const config = useGetBotConfig();

  // Mutations with automatic cache invalidation
  const updateConfig = useUpdateBotConfig({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetBotConfigQueryKey() });
      },
    },
  });

  const disconnect = useDisconnectBot({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotLogsQueryKey() });
        // Force an immediate refetch of status to update the UI
        setTimeout(() => queryClient.refetchQueries({ queryKey: getGetBotStatusQueryKey() }), 500);
      },
    },
  });

  return {
    status,
    qr,
    logs,
    config,
    updateConfig,
    disconnect,
  };
}
