import { useBot } from "@/hooks/use-bot";
import { useToast } from "@/hooks/use-toast";
import { StatusWidget } from "@/components/bot/StatusWidget";
import { QrWidget } from "@/components/bot/QrWidget";
import { ConfigWidget, ConfigFormValues } from "@/components/bot/ConfigWidget";
import { LogsWidget } from "@/components/bot/LogsWidget";
import { CommandsCard } from "@/components/bot/CommandsCard";
import { motion } from "framer-motion";
import { Download, Loader2 } from "lucide-react";
import { useState } from "react";

export default function Dashboard() {
  const { status, qr, logs, config, updateConfig, disconnect } = useBot();
  const { toast } = useToast();

  const handleSaveConfig = async (data: ConfigFormValues) => {
    try {
      await updateConfig.mutateAsync({ data });
      toast({ 
        title: "Configurações Salvas", 
        description: "As atualizações foram aplicadas com sucesso.",
        className: "bg-primary text-primary-foreground border-none"
      });
    } catch (error) {
      toast({ 
        variant: "destructive", 
        title: "Erro ao Salvar", 
        description: "Não foi possível atualizar as configurações." 
      });
    }
  };

  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const a = document.createElement("a");
      a.href = `${import.meta.env.BASE_URL}api/bot/download`.replace(/\/\//g, "/");
      a.download = "bot-mario-completo.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      toast({
        title: "Download Iniciado",
        description: "O arquivo bot-mario-completo.zip está sendo baixado.",
        className: "bg-primary text-primary-foreground border-none",
      });
    } catch {
      toast({ variant: "destructive", title: "Erro no Download", description: "Não foi possível baixar o bot." });
    } finally {
      setTimeout(() => setIsDownloading(false), 3000);
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnect.mutateAsync();
      toast({ 
        title: "Bot Desconectado", 
        description: "Sessão do WhatsApp encerrada com sucesso." 
      });
    } catch (error) {
      toast({ 
        variant: "destructive", 
        title: "Erro", 
        description: "Falha ao desconectar o bot." 
      });
    }
  };

  return (
    <div className="min-h-screen relative bg-background text-foreground selection:bg-primary/30 selection:text-white">
      {/* Immersive Background */}
      <img
        src={`${import.meta.env.BASE_URL}images/dashboard-bg.png`}
        alt="Background Pattern"
        className="fixed inset-0 w-full h-full object-cover opacity-15 pointer-events-none mix-blend-screen"
      />
      <div className="fixed inset-0 bg-gradient-to-b from-background/40 via-background/80 to-background pointer-events-none" />

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {/* Header Section */}
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-10"
        >
          <div className="flex items-center gap-6">
            <div className="relative group cursor-default">
              <div className="absolute inset-0 bg-primary/30 blur-2xl rounded-full transition-all group-hover:bg-primary/50 group-hover:blur-3xl" />
              <img 
                src={`${import.meta.env.BASE_URL}images/mario-avatar.png`} 
                alt="Mário Avatar" 
                className="w-20 h-20 md:w-24 md:h-24 rounded-full border-2 border-primary/40 shadow-2xl shadow-primary/20 relative z-10 object-cover" 
              />
              {status.data?.isRunning && (
                <span className="absolute bottom-1 right-1 w-5 h-5 bg-primary border-4 border-background rounded-full z-20 animate-pulse shadow-[0_0_10px_rgba(37,211,102,1)]" />
              )}
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white tracking-tight">
                Bot MÁRIO
              </h1>
              <p className="text-muted-foreground mt-1 text-base md:text-lg font-medium">
                Assistente Autônomo para WhatsApp
              </p>
            </div>
          </div>

          {/* Download button */}
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-primary/30 bg-primary/10 hover:bg-primary/20 text-primary font-semibold text-sm transition-all duration-200 shadow-lg shadow-primary/10 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isDownloading
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Preparando...</>
              : <><Download className="w-4 h-4" /> Baixar Bot Completo</>
            }
          </button>
        </motion.header>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column - Real-time Status */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-8 lg:col-span-4"
          >
            <StatusWidget 
              status={status.data} 
              config={config.data}
              isLoading={status.isLoading} 
              onDisconnect={handleDisconnect}
              isDisconnecting={disconnect.isPending}
            />
            
            {status.data?.state === "qr_ready" && qr.data?.qrDataUrl && (
              <QrWidget qrDataUrl={qr.data.qrDataUrl} />
            )}
          </motion.div>

          {/* Right Column - Config & Logs */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-8 lg:col-span-8 flex flex-col"
          >
            <ConfigWidget 
              config={config.data} 
              onSave={handleSaveConfig} 
              isPending={updateConfig.isPending} 
            />
            
            <CommandsCard mode={config.data?.mode} prefix={config.data?.prefix} />

            <LogsWidget 
              logs={logs.data?.logs} 
              isLoading={logs.isLoading} 
            />
          </motion.div>

        </div>
      </main>
    </div>
  );
}